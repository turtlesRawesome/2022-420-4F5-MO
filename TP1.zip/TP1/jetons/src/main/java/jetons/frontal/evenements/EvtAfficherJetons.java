package jetons.frontal.evenements;

import ca.ntro.app.frontend.events.EventNtro;

public class EvtAfficherJetons extends EventNtro{

}
